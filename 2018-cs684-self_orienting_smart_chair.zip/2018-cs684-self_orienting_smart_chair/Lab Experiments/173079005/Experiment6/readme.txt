It was just installation of TI RTOS   NO coding 
