Project Name: Self Orienting Smart Chair

Team Members:
1. Patil Akhilesh Subhash (173079005)
2. Supriya Asutkar(174360005)
3. Rahul Pari(173100041)


Project Description:

We often find in offices , or in labs , Chairs are not oriented properly . Sometimes we become little lazy
and do not place chairs in proper positions. The aim of this project is to design a prototype for self orienting
smart chair which can localize itself and navigate to the desired position. The future outcome of this project
is like consider a situation where all chairs are randomly oriented inside a room. When we give command
all chairs should get automatically oriented and nevigate to their default positions.
Figure 1 shows the scene from hostel 1 , where at night chairs were randomly oriented and it looks messy.
Our motivation for this project was from here. These chair should be smart enough to orient and organize
properly as shown in right picture. For that we need to have mechanism to localize the chairs and then move
accordinly to the destinations to organize them properly

Demonstration Video 
=========================  

1)  https://www.youtube.com/watch?v=Ns7mtMZ8dZM
2)  https://www.youtube.com/watch?v=5hbmWOduP8k 

