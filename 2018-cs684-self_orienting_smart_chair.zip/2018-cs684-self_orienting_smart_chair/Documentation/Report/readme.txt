2018 - CS684  Group  : Self orienting smart chair
================================================ 
 
We have written report in LATEX , so we are providing both pdf formated report file and LATEX code for the same 


 

